#!/bin/sh

# This shell script creates a binary image and an IAR EWAVR32 assembly header
# file from the Intel HEX image and then programs the ISP forcing word (User
# page).

# Copyright (C) 2006-2008, Atmel Corporation All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation and/
# or other materials provided with the distribution.
#
# 3. The name of ATMEL may not be used to endorse or promote products derived
# from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
# SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


echo
echo Creating \`isp.bin\' from \`isp.hex\'.
avr32-objcopy -I ihex -O binary isp.hex isp.bin

echo
echo Creating \`isp.h\' from \`isp.bin\'.
od -A n -t x1 -v isp.bin | sed -e 's/[0-9a-fA-F]\+/0x\U\0,/g' -e 's/\(.*\),/  DC8\1\r/' > isp.h

echo
echo Programming ISP forcing word.
echo -ne MSIF > isp_force.bin
avr32program program -finternal@0x80000000,256Kb -cxtal -e -v -O0x808001F8 -Fbin isp_force.bin
rm -f isp_force.bin
