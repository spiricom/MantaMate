/*
 * IncFile1.h
 *
 * Created: 10/23/2015 2:08:16 PM
 *  Author: AirWolf
 */ 


#ifndef INCFILE1_H_
#define INCFILE1_H_

#include <stdint.h>

void Write7Seg(uint8_t value);



#endif /* INCFILE1_H_ */

